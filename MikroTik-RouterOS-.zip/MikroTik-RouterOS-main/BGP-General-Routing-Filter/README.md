# Mikrotik RouterOS v7 routing-filter

With the Mikrotik routeros v7 release, the rules used in v6 have completely changed, so you will have some difficulty when moving from v6 to v7. Since the BGP filter structure has been completely redesigned and readability has changed, it has become difficult to find documentation on the internet.

I have put together some routing-filters that you can use in v7.
