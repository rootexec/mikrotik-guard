# MikroTik Komut Setleri

Bu depo, MikroTik yönlendiricileri için hazırladığım ve paylaşmaktan mutluluk duyduğum bazı komut setlerini içerir. Bu komut setleri, MikroTik cihazlarınızı yapılandırmak ve yönetmek için faydalı olabilir.


https://alptekin.sunnetci.net

